import Header from "../../src/features/home/Header";

function boy(){
    return (
        <Header></Header>
    );
}

export default boy;