export class CategoryFormValues {
    categoryName?: string;
}

export class Category{
    categoryId?: number;
    categoryName: string = "";
}